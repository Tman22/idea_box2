(function() {
  Teaspoon.setFramework(Teaspoon.Mocha);

  window.env = mocha.setup("bdd");

}).call(this);
